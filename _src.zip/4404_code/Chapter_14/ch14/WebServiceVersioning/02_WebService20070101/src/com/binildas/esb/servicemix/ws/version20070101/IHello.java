
package com.binildas.esb.servicemix.ws.version20070101;

//	version20070101.ws.servicemix.esb.binildas.com

public interface IHello{

	String hello(String param);

}