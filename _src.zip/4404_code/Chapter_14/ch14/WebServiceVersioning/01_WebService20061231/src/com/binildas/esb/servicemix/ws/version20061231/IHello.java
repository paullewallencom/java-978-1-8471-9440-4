
package com.binildas.esb.servicemix.ws.version20061231;

//	version20061231.ws.servicemix.esb.binildas.com

public interface IHello{

	String hello(String param);

}