
public interface IHello{

    String sayHello(String name);
}