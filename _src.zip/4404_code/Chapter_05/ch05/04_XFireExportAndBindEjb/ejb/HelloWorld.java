package examples.webservices.basic.statelessSession;

//import java.rmi.RemoteException;
import javax.ejb.EJBObject;


public interface HelloWorld extends HelloWorldBI, EJBObject {

}
