
package com.binildas.apache.axis.AxisEndToEnd;

public class JMSTransportForAxis extends org.apache.axis.client.Transport {

	public JMSTransportForAxis(){

	    transportName = "JMSTransportForAxis";
	}

}