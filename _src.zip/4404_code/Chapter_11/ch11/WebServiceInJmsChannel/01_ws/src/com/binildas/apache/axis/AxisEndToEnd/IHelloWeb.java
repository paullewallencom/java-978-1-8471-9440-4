
package com.binildas.apache.axis.AxisEndToEnd;

public interface IHelloWeb extends IHello, java.rmi.Remote {

}
