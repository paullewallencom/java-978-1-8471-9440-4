
package com.binildas.apache.axis.AxisEndToEnd;

public interface IHello{

	String hello(String param);

}