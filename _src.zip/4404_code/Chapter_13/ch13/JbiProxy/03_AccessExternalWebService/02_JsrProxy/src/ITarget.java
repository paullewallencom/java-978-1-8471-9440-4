
package test;

public interface ITarget{

    String hello(String input);

}
