package test;

public interface IHelloProxy {

    public String hello(String input);

}
