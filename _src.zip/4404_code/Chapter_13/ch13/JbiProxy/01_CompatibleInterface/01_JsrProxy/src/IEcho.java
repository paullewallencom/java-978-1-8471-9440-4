package test;

public interface IEcho {

    public String echo(String input);

}
