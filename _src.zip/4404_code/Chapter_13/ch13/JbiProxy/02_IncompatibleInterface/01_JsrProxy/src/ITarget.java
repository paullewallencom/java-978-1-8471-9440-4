
package test;

public interface ITarget{

    String echo(String input);

}
