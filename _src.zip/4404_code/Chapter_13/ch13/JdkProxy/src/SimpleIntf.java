
public interface SimpleIntf{

	public void print();

}

