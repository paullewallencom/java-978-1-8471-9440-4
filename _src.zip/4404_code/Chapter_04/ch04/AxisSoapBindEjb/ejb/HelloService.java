package samples;

public interface HelloService extends HelloServiceBI, javax.ejb.EJBObject {


}
