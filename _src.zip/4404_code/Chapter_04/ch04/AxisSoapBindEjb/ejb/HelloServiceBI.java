package samples;

public interface HelloServiceBI{

	String hello(String phrase) throws java.io.IOException;

}
