package samples;

public interface DestinationHelloServiceBI{

	String hello(String phrase) throws java.io.IOException;

}
