package samples;

public interface BridgeHelloServiceBI{

	String broker(String phrase) throws java.io.IOException;

}
